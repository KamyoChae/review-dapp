<template>
    <div class="banner-wrapper">

        <div class="imgbox">
            <div class="leftbox"> 
                <a :href="leftbox.url" target="_brank">
                    <img :src="leftbox.image" alt="">
                </a>
            </div>
            <div class="rightbox" >
                <a :href="item.url" target="_brank" v-for='item in this.rightbox' :key="item.url">
                    <img :src="item.image" alt="">
                </a>   
            </div>
        </div>
    </div>

</template>

<script>
export default {
    data(){
        return { 
            leftbox:[],
            rightbox:[],
        }
    },
    methods:{
        getbanner(){
            this.axios.get('/api/banner/banner/?type=2&lang=zh').then(res=>{  
                this.swapbox(res.data.results)
            }).catch(err=>{
                console.log("err")
            })
        },
        swapbox(arrList){
            this.leftbox = arrList[0]
            arrList.shift()
            this.rightbox = arrList 
        }
    },
    mounted(){
        this.getbanner()
    }
}
</script>

<style lang='stylus' scoped>

@import '~@/assets/css/util.styl'

.banner-wrapper
    position relative
    width 100%
    height 24rem
    background $mainColor
    font-size 0 
    .imgbox
        box-sizing border-box
        width 95%
        position absolute 
        z-index 5
        margin auto 
        left 0
        right 0  
        .leftbox, .rightbox  
            vertical-align top
            box-sizing border-box
            width 50%
            height 0 
            display inline-block  
            a
                overflow hidden
                margin .5%
                box-sizing border-box 
                display inline-block
                img 
                    width 100%
                    transition all .25s
                    &:hover
                        transform scale(1.1)
        .rightbox  
            box-sizing border-box
            a
                width 47%
                img 
                    width 100%
    
    &:before
        content ""
        display block
        position absolute
        width 100%
        background-image url(https://dapp.review/assets/39c8c85f.svg)
        background-size 100%
        bottom 0
        height 0
        left 0
        padding-bottom 2%
</style>